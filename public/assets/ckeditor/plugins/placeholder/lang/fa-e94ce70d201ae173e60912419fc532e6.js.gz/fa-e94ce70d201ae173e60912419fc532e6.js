/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","fa",{placeholder:{title:"ویژگیهای محل نگهداری",toolbar:"ایجاد یک محل نگهداری",text:"متن محل نگهداری",edit:"ویرایش محل نگهداری",textMissing:"محل نگهداری باید محتوی متن باشد."}});